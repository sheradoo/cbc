async function tokenTousd(value) {
            try {
                let usdP = '<%= process.env.USDPRICE %>';
                const usdVal = value * usdP;
                return usdVal;
            } catch (error) {
                console.error("Error converting token to trc20:", error);
                return null;
            }
        }

        async function usdTotoken(value) {
            try {
                let usdP = '<%= process.env.USDPRICE %>';
                const tokenVal = value / usdP;
                return tokenVal;
            } catch (error) {
                console.error("Error converting token to trc20:", error);
                return null;
            }
        }

        function removeCurrencyAndNonNumeric(inputString) {
            const pattern = /[-+]?([0-9]*\.[0-9]+|[0-9]+)/g;
            const cleanedArray = inputString.match(pattern);
            const cleanedString = cleanedArray ? cleanedArray.join("") : "";
            return cleanedString;
        }

        let token = document.getElementById("token-input");
        let usd = document.getElementById("usd-input");
        let inputTimeout;

        function handleTokenInput() {
            clearTimeout(inputTimeout);
            inputTimeout = setTimeout(() => {
                let tokenValue = removeCurrencyAndNonNumeric(token.value);
                if (!tokenValue) {
                    token.focus();
                    return;
                }
                tokenTousd(tokenValue).then((usdVal) => {
                    usd.value = usdVal.toFixed(8);
                });
            }, 500);
        }

        function handleUsdInput() {
            clearTimeout(inputTimeout);
            inputTimeout = setTimeout(() => {
                let usdValue = removeCurrencyAndNonNumeric(usd.value);
                if (!usdValue) {
                    usd.focus();
                    return;
                }
                usdTotoken(usdValue).then((tokenVal) => {
                    token.value = tokenVal.toFixed(2);
                });
            }, 500);
        } 